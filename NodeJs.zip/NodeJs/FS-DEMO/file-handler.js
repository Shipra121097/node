var fs = require("fs");
var path = require("path");
exports.writeContent = (filename, content) => {
    var filePath = path.resolve(__dirname, "my files", filename);
    fs.open(filePath, "w", (err, fd) => {
        if (err) {
            console.log("failed to open file");
            return;
        }
        fs.write(fd, Buffer.from(content), (err, noofBytes, buff) => {
            if (err) {
                console.log("failed to write content");
                return;
            }
            console.log("Successfully writen the content");
            fs.close(fd, (err) => {
                if (err) {
                    console.log("Error in closing file");
                    return;
                }
                console.log("file colsed");
            });
        });
    });
}

exports.readContent = (filename) => {

    var filePath = path.resolve(__dirname, "my files", filename);


    fs.open(filePath, "r", (err, fd) => {
        if (err) {
            console.log("failed to open file");
            return;
        }

        var buffer = Buffer.alloc(1024);
        fs.read(fd, buffer, 0, 1024, 0, (err, bytesRead, buff) => {
            if (err) {
                console.log("failed to read");
                return;
            }
            var a = buff.toString();
           // callback(a.toUpperCase());
            console.log(buff.toString());
            fs.close(fd, (err) => {
                console.log("File closedddddd");
            });
        });
    });
}