var {writeToFilesStream, readFromFileStream}=require("./stream-demo")

var {writeContent,readContent}=require("./file-handler");
var data="Hellloooooooooooo";
var filename="greet.txt";
//writeContent(filename,data);
//readContent(filename);
writeToFilesStream(filename,data);
readFromFileStream(filename)