var fs = require("fs");
var path = require("path");

exports.writeToFilesStream = (filename, content) => {
    var filePath = path.resolve(__dirname, "my files", filename);
    var stream = fs.createWriteStream(filePath, { encoding: "utf-8" });
    stream.write(content);
    stream.close();
}
    exports.readFromFileStream = (filename) => {
        var filePath = path.resolve(__dirname, "my files", filename);
        var stream = fs.createReadStream(filePath, { encoding: "utf-8" });
        var content="";
        stream.on("data", (chunk) => {
            //console.log(chunk.length);
            content += chunk;

        });
        stream.on("end", () => {

            console.log("streaming completed");
            console.log(content);
            stream.close();
        })
    }