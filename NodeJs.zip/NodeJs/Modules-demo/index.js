var calc =require("./calculator")
function demo(){
    console.log("hello");
}
demo()
calc.add(5,6);